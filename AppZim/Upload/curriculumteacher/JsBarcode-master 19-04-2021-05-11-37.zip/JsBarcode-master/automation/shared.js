module.exports = {};

module.exports.minifiedFilename = function(name){
	return "JsBarcode." + name + ".min.js";
};
